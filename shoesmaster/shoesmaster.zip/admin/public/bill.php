<?php
    // cataloglist
    $catalog_html='';
    $i=1;
    foreach ($cataloglist as $item) {
        extract($item);
        if($pttt==1){
          $thanhtoan='thanh toán tiền mặt  ';
        }else{
          $thanhtoan= 'thanh toán ví điện tử ';
        }
        if($ship==0){
            $tinhtrang='đang xác nhận đơn hàng ';
        }else{
            $tinhtrang='đã xác nhận đơn hàng ';
        }
        
        
        $linkedit='<a href="index.php?page=updatebillform&id='.$id.'">Sửa tính trạng </a>';
        // $linkdel='<a href="index.php?page=deletebill&id='.$id.'">Xóa</a>';
        $catalog_html.='<tr>
                            <td>'.$i.'</td>
                            <td>'.$maHD.'</td>
                            <td>'.$nguoidat_ten.'</td>
                            <td>'.$nguoidat_email.'</td>
                            <td>'.$nguoidat_tel.'</td>
                            <td>'.$nguoidat_diachi.'</td>
                            <td>'.$thanhtoan.'</td>
                            <td>'.$tinhtrang.'  </td>
                            <td>'.$tongthanhtoan.'</td>
                            <td> '.$linkedit.' </td>
                        </tr>';
        $i++;
    }
 
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Đơn hàng</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">quản lý đặt hàng </li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
          
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <!-- <div class="card-header">
                            <h3 class="card-title ">Danh sách chủ đề</h3>
                        </div> -->
                        <!-- /.card-header -->
                        <div class="card-body">
                      
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">mã đơn hàng  </th>
                                        <th scope="col">tên người đặt  </th>
                                        <th scope="col"> gmail</th>
                                        <th scope="col"> sô điện thoại </th>
                                        <th scope="col">địa chỉ   </th>
                                        <th scope="col"> phương thức thanh toán</th>
                                        <th scope="col"> tính trạng </th>
                                        <th scope="col"> tổng đơn hàng </th>
                                        <th scope="col">hành động  </th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?=$catalog_html?>
                                </tbody>
                                <!-- <tfoot>

                                <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Tên chủ đề</th>
                                        <th scope="col">Chế độ</th>
                                        <th scope="col">Số lượng câu hỏi</th>
                                        <th scope="col">Thao tác</th>
                                    </tr>
                                </tfoot> -->
                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->

